from django.apps import AppConfig

class DoctorEspecialidadConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.doctor_especialidad'
